/**
 *
 *  @author Zhura Serhii S15693
 *
 */

package zadanie1;


public abstract 
	class Spiewak {

	public String nazwisko;
	static int staticNumber = 1;
	public int mainNumber = 1;
	
	
	public Spiewak(String nazwisko) {
		this.nazwisko = nazwisko;
		mainNumber = staticNumber++;
	}
	
	
	public String toString(){
			return "(" + mainNumber + ") " + nazwisko + ": " + spiewaj();
	}
	
	
	public abstract String spiewaj();
	
	
	public static Spiewak najglosniej(Spiewak[] sp) {
		
		Spiewak main = sp[0];
		int max = 0;
		
		for(int i = 1; i < sp.length; i++){
			int count = 0;
			
			char[] tab = sp[i].spiewaj().toCharArray();
			for(int j = 0; j < sp[i].spiewaj().length(); j++)
				if(tab[j] >= 'A' && tab[j] <= 'Z')
					count++;
			if(count > max){
				max = count;
				main = sp[i];
			}
		}
		
		return main;
	}
}
	
	

