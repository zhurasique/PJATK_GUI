/**
 *
 *  @author Zhura Serhii S15693
 *
 */
package zadanie2;

public interface Reversible {

	public Reversible reverse();

}
