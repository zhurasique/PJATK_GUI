/**
 *
 *  @author Zhura Serhii S15693
 *
 */
package zadanie2;

public 
	class ReversibleDouble implements Reversible {
		public double reversible;
		
		public ReversibleDouble(double reversible){
			this.reversible = reversible;
		}

		public String toString(){
			return Double.toString(reversible);
		}
		
		@Override
		public Reversible reverse() {
			reversible = 1.0 / reversible;
			return this;
		}
			
}
