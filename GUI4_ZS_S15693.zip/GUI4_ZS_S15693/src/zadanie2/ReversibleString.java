/**
 *
 *  @author Zhura Serhii S15693
 *
 */
package zadanie2;

public 
	class ReversibleString implements Reversible {
		public String reversible;
		
		public ReversibleString(String reversible){
			this.reversible = reversible;
		}

		public String toString(){
			return reversible;
		}
		
		@Override
		public Reversible reverse() {
			
			String reverse = "";
			
			for (int i = reversible.length() - 1; i >= 0; i--)
				reverse += this.reversible.charAt(i);
			reversible = reverse;
			
			return this;
		}
}
