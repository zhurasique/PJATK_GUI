/**
 *
 *  @author Zhura Serhii S15693
 *
 */

package zadanie1;

import java.util.Iterator;

public 
	class Hailstone implements Iterable<Integer>{

    private int ini;
    private int zero = 0;

    public Hailstone(int ini){
        if (ini >= 1)
            this.ini = ini;
    }

    @Override
    public Iterator<Integer> iterator() {
        return new Iterator<Integer>() {
        	
            @Override
            public boolean hasNext() {
                return ini != zero;
            }
            
            
            @Override
            public Integer next() {
                if (ini == 1){
                	ini = zero;
                    return 1;
                }
                if (ini % 2 == zero)
                	ini /= 2;
                else
                	ini = 1 + 3 * ini;
                return ini;
            }
        };
        
    }
}
