/**
 *
 *  @author Zhura Serhii S15693
 *
 */

package zadanie2;

import java.math.BigDecimal;
import java.math.RoundingMode;

public 
	class getBigDecimal extends BigDecimal {
	
	private static final long serialVersionUID = 1L; // nie potrzebne.
	
	public getBigDecimal(String val) {
        super(val);
    }
 
    @Override
    public BigDecimal divide(BigDecimal divisor) {
        return super.divide(divisor, 10, RoundingMode.HALF_UP);
    }
}