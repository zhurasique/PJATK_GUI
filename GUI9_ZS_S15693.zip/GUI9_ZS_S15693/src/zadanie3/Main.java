/**
 *
C*  @author Zhura Serhii S15693
 *
 */

package zadanie3;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class Main {

	public static void main(String[] args) {
		
		char input;
		String line = "";
		  
		input = JOptionPane.showInputDialog((line.length() > 0 ? line + "\n" : "") + "Wpisz A-G." + "").charAt(0);
		JFrame frame = new JFrame();
		frame.setSize(900, 400);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JButton buttonFirst = new JButton("Przycisk 1");
		JButton buttonSecond = new JButton("P 2");
		JButton buttonThird = new JButton("Większy przycisk numer 3");
		JButton buttonFourth = new JButton("Przycisk 4");
		JButton buttonFifth = new JButton("P 5");
		
		if(input == 'A'){
			frame.setLayout(new BorderLayout());
			frame.add(buttonFirst, BorderLayout.NORTH);
			frame.add(buttonSecond, BorderLayout.SOUTH);
			frame.add(buttonThird, BorderLayout.WEST);
			frame.add(buttonFourth, BorderLayout.EAST);
			frame.add(buttonFifth, BorderLayout.CENTER);
		}else if(input == 'B'){
			frame.setLayout(new FlowLayout());
			frame.add(buttonFirst);
			frame.add(buttonSecond);
			frame.add(buttonThird);
			frame.add(buttonFourth);
			frame.add(buttonFifth);
		}else if(input == 'C'){
			frame.setLayout(new FlowLayout(FlowLayout.LEFT));
			frame.add(buttonFirst);
			frame.add(buttonSecond);
			frame.add(buttonThird);
			frame.add(buttonFourth);
			frame.add(buttonFifth);
		}else if(input == 'D'){
			frame.setLayout(new FlowLayout(FlowLayout.RIGHT));
			frame.add(buttonFirst);
			frame.add(buttonSecond);
			frame.add(buttonThird);
			frame.add(buttonFourth);
			frame.add(buttonFifth);
		}else if(input == 'E'){
			frame.setLayout(new GridLayout());
			frame.add(buttonFirst);
			frame.add(buttonSecond);
			frame.add(buttonThird);
			frame.add(buttonFourth);
			frame.add(buttonFifth);
		}else if(input == 'F'){
			frame.setLayout(new GridLayout(0, 1));
			frame.add(buttonFirst);
			frame.add(buttonSecond);
			frame.add(buttonThird);
			frame.add(buttonFourth);
			frame.add(buttonFifth);
		}else if(input == 'G'){
			frame.setLayout(new GridLayout(3, 2));
			frame.add(buttonFirst);
			frame.add(buttonSecond);
			frame.add(buttonThird);
			frame.add(buttonFourth);
			frame.add(buttonFifth);
		}else{
			JOptionPane.showMessageDialog(new JFrame(), "Błąd. Wpisz A-G!");
			System.exit(1);
		}
		frame.setVisible(true);
	}	
}