/**
 *
*  @author Zhura Serhii S15693
 *
 */

package zadanie2;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.border.MatteBorder;
import javax.swing.border.TitledBorder;

public class Main {
	
	public static void main(String[] args) {
		JFrame frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JPanel panel = new JPanel();

		panel.setLayout(new BorderLayout());
		JButton northButton = new JButton("<html><h2><font color=\"yellow\">NORTH");
		JButton southButton = new JButton("<html><h2><font color=\"white\">SOUTH");
		JButton eastButton = new JButton("<html><h2><font color=\"black\">EAST");
		JButton westButton = new JButton("<html><h2><font color=\"blue\">WEST");
		JButton centerButton = new JButton("<html><h2><font color=\"cyan\">CENTER");
		
		northButton.setBorder(new EmptyBorder(1, 2, 3, 4));
		southButton.setBorder(new TitledBorder("Hello"));
		eastButton.setBorder(new EtchedBorder());
		westButton.setBorder(new MatteBorder (1, 2, 3, 4, Color.BLACK));
		centerButton.setBorder(new BevelBorder(0, Color.WHITE, Color.WHITE));
		
		northButton.setFont(new Font("Plain", Font.PLAIN, 20));
		southButton.setFont(new Font("Center_Baseline", Font.CENTER_BASELINE, 21));
		eastButton.setFont(new Font("Italic", Font.ITALIC, 22));
		westButton.setFont(new Font("Hanging_Baseline", Font.HANGING_BASELINE, 23));
		centerButton.setFont(new Font("Truetype_Font", Font.TRUETYPE_FONT, 24));
		
		northButton.setBackground(Color.BLACK);
		southButton.setBackground(Color.BLUE);
		eastButton.setBackground(Color.RED);
		westButton.setBackground(Color.YELLOW);
		centerButton.setBackground(Color.CYAN);
		
		panel.add(westButton, BorderLayout.WEST);
		panel.add(eastButton, BorderLayout.EAST);
		panel.add(southButton, BorderLayout.SOUTH);
		panel.add(northButton, BorderLayout.NORTH);
		panel.add(centerButton, BorderLayout.CENTER);

		
		northButton.setToolTipText("Click this button to disable the middle button.");
		southButton.setToolTipText("Click this button to disable the middle");
		eastButton.setToolTipText("Click this button to disable the");
		westButton.setToolTipText("Click this button to disable");
		centerButton.setToolTipText("Click this button to");
		
		frame.getContentPane().add(panel);
		frame.setPreferredSize(new Dimension(600, 350));
		frame.pack();
		frame.setVisible(true);
		frame.setLocationRelativeTo(null);
	}
}
