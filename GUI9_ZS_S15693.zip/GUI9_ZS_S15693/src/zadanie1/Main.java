/**
 *
 *  @author Zhura Serhii S15693
 *
 */

package zadanie1;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JTextArea;



public class Main {

  public static void main(String[] args) {
	  
	  JFrame frame = new JFrame(); 
	  frame.setSize(600, 180);
	  
	  JTextArea textArea = new JTextArea(
			    "Hello, my name is Serhii, i'm from Ukraine.\n" +
			    "I will get 5 from GUI, i'm superman!"
			);
	  textArea.setForeground(Color.WHITE);
	  textArea.setFont(new Font("Serif", Font.PLAIN, 24));
	  textArea.setLineWrap(true);
	  textArea.setWrapStyleWord(true);
	  textArea.setBackground(Color.BLUE);
	  
	  frame.add(textArea);
	  frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	  frame.setVisible(true); 
	  
  }
}
