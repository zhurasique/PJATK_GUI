/**
 *
 *  @author Zhura Serhii S15693
 *
 */

package zadanie1;


import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;


public 
	class Panel implements ActionListener {

	private String operation;
	private int firstValue;
	
	public Panel() {
		getPanel();
	}

	public void getPanel() {

		firstValue = 0;
		operation = "";
		
		JPanel panel = new JPanel();
		JFrame frame = new JFrame("Calculator");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		panel.setLayout(null);
		
		JButton n0 = new JButton("0");
		JButton n1 = new JButton("1");
		JButton n2 = new JButton("2");
		JButton n3 = new JButton("3");
		JButton n4 = new JButton("4");
		JButton n5 = new JButton("5");
		JButton n6 = new JButton("6");
		JButton n7 = new JButton("7");
		JButton n8 = new JButton("8");
		JButton n9 = new JButton("9");
		
		JButton add = new JButton("+");
		JButton rem = new JButton("-");
		JButton mul = new JButton("*");
		JButton div = new JButton("/");
		JButton eq = new JButton("=");
		JButton clr = new JButton("C");
		
		JLabel op = new JLabel("");
		JLabel res = new JLabel("");
		
		
		op.setFont(new Font("Plain", Font.PLAIN, 35));
		res.setFont(new Font("Plain", Font.PLAIN, 35));
		
		n1.setBounds(0,35,75,75);
		n2.setBounds(75,35,75,75);
		n3.setBounds(150,35,75,75);
		n4.setBounds(0,110,75,75);
		n5.setBounds(75,110,75,75);
		n6.setBounds(150,110,75,75);
		n7.setBounds(0,185,75,75);
		n8.setBounds(75,185,75,75);
		n9.setBounds(150,185,75,75);
		n0.setBounds(75,260,75,75);
		
		clr.setBounds(0,260,75,75);
		eq.setBounds(150,260,75,75);
		
		add.setBounds(235,35,75,75);
		rem.setBounds(235,110,75,75);
		div.setBounds(235,185,75,75);
		mul.setBounds(235,260,75,75);
		
		op.setBounds(10,0,325,35);
		res.setBounds(10,0,325,35);
		
		panel.add(n1);
		panel.add(n2);
		panel.add(n3);
		panel.add(n4);
		panel.add(n5);
		panel.add(n6);
		panel.add(n7);
		panel.add(n8);
		panel.add(n9);
		panel.add(n0);
		panel.add(mul);
		panel.add(clr);
		panel.add(eq);
		panel.add(div);
		panel.add(add);
		panel.add(rem);
		panel.add(op);
		panel.add(res);
		
		
		frame.getContentPane().add(panel);
		frame.setPreferredSize(new Dimension(325, 375));

		frame.pack();
		frame.setVisible(true);
		frame.setLocationRelativeTo(null);

	n0.addActionListener(new ActionListener() {
         @Override
         public void actionPerformed(ActionEvent e) {
        	 op.setText(op.getText()+"0");
         }
     });
	n1.addActionListener(new ActionListener() {
         @Override
         public void actionPerformed(ActionEvent e) {
        	 op.setText(op.getText()+"1");
         }
     });
	n2.addActionListener(new ActionListener() {
         @Override
         public void actionPerformed(ActionEvent e) {
        	 op.setText(op.getText()+"2");
         }
     });
	n3.addActionListener(new ActionListener() {
         @Override
         public void actionPerformed(ActionEvent e) {
        	 op.setText(op.getText()+"3");
         }
     });
	n4.addActionListener(new ActionListener() {
         @Override
         public void actionPerformed(ActionEvent e) {
        	 op.setText(op.getText()+"4");
         }
     });
	n5.addActionListener(new ActionListener() {
         @Override
         public void actionPerformed(ActionEvent e) {
        	 op.setText(op.getText()+"5");
         }
     });
	n6.addActionListener(new ActionListener() {
         @Override
         public void actionPerformed(ActionEvent e) {
        	 op.setText(op.getText()+"6");
         }
     });
	n7.addActionListener(new ActionListener() {
         @Override
         public void actionPerformed(ActionEvent e) {
        	 op.setText(op.getText()+"7");
         }
     });
	n8.addActionListener(new ActionListener() {
         @Override
         public void actionPerformed(ActionEvent e) {
        	 op.setText(op.getText()+"8");
         }
     });
	n9.addActionListener(new ActionListener() {
         @Override
         public void actionPerformed(ActionEvent e) {
        	 op.setText(op.getText()+"9");
         }
     });
	
	clr.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
        	if(op.getText().length() != 0){
            String tmp = op.getText();
            op.setText(tmp.substring(0,tmp.length()-1));
        	}
        }
    });
	
	add.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            firstValue = Integer.valueOf(op.getText());
            op.setText("");
            operation = "+";
        }
    });
	
    mul.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            firstValue = Integer.valueOf(op.getText());
            op.setText("");
            operation = "*";
        }
    });
    
    div.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            firstValue = Integer.valueOf(op.getText());
            op.setText("");
            operation = "/";
        }
    });
    
    rem.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            firstValue = Integer.valueOf(op.getText());
            op.setText("");
            operation = "-";
        }
    });
    
    eq.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            
        	int secondValue = Integer.valueOf(op.getText());
            
        	op.setText("");
        	
            if("+".equals(operation))
                res.setText(firstValue + " + " + secondValue + " = " + (firstValue+secondValue));  	
            
            if("-".equals(operation))
            	res.setText(firstValue + " - " + secondValue + " = " + (firstValue-secondValue));
            
            if("*".equals(operation))
            	res.setText(firstValue + " * " + secondValue + " = " + (firstValue*secondValue));
            
            if("/".equals(operation))
            	if(secondValue != 0)
            		res.setText(firstValue + " / " + secondValue + " = " + (firstValue/secondValue));
            	else
            		res.setText("ERR");

            
            clr.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    res.setText("");
                	}
            });
            
            firstValue = 0;
            operation = "";
        }
       
    });
    		
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		
	}
}
