/**
 *
 *  @author Zhura Serhii S15693
 *
 */

package zadanie1;


public 
	class Calc {
	
	double res;
	String op;
	
	public Calc(){
		
	}
	
	public double add(int arg1, int arg2) {
		res = arg1 + arg2;
		op = arg1 + " + " + arg2 + " = " + res; 
		return res;
	}
	
	public double substract(double arg1, double arg2) {
		res = arg1 - arg2;
		op = arg1 + " - " + arg2 + " = " + res; 
		return res;
	}

	public double multiply(int arg1, double arg2) {
		res = arg1 * arg2;
		op = arg1 + " * " + arg2 + " = " + res; 
		return res;
	}

	public double divide(double num1, double num2){ 
		res = num1 / num2; 
		if (Double.isInfinite(res)) { 
			op = num1 + " / " + num2 + " = ERR"; 
			res = Double.NaN; 
		}else 
			op = num1 + " / " + num2 + " = " + res; 
			return res; 
		}
	
	public String toString(){
		return op;
	}
}  
