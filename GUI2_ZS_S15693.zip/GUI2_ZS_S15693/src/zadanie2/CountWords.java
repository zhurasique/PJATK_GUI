/**
 *
 *  @author Zhura Serhii S15693
 *
 */

package zadanie2;

import java.util.*;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class CountWords{
	
	public String string;

	public CountWords(String string) throws IOException{
		
		this.string = string;
		this.countWords();
	}

	Map<String, Integer> lhm = new LinkedHashMap<String, Integer>();
	
	public void countWords() throws IOException{
		
		try {
			FileReader file = new FileReader(string);
			Scanner scann = new Scanner(file);
			
			while (scann.hasNext()) {
				String tmp = scann.next();
				if (lhm.get(tmp) != null) 
					lhm.put(tmp, lhm.get(tmp) + 1);
				 else 
					 lhm.put(tmp, 1);
			}
			scann.close();
		} catch (FileNotFoundException fnfe) {
			System.out.println("***");
		} 
	}
	
	public List<String> rslt;
	
	public List<String> getResult() throws IOException{
		rslt = new ArrayList<String>();
		for (Map.Entry<String, Integer> put : lhm.entrySet()) 
			rslt.add(put.getKey() + " " + put.getValue());
		return rslt;
	}
}
