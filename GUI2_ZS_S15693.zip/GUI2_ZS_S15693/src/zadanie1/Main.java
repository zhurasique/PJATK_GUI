/**
 *
 *  @author Zhura Serhii S15693
 *
 */

package zadanie1;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList; 
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main {

  public static void main(String[] args) throws Exception{
	  
    try{
    	String fname = System.getProperty("user.home") + "/tab.txt";
    	
    	ArrayList<Integer> array = new ArrayList<Integer>();
    	FileInputStream fis = new FileInputStream(new File(fname));
    	
    	Pattern pattern1 = Pattern.compile("-?\\d+");
		Pattern pattern2 = Pattern.compile("[^\\d\\s\\-]+?|-( |$)|\\d+-\\d+");
		
    	String tmp = "";
    	int count;
    		while((count = fis.read()) != -1)
    			tmp = tmp + (char)count;
    		fis.close();
    		
    	Matcher matcher1 = pattern1.matcher(tmp);
    	Matcher matcher2 = pattern2.matcher(tmp);
    	if(!matcher2.find()){
    		while(matcher1.find()){
    			int i = Integer.parseInt(matcher1.group()); 
    	    	array.add(i); 
    		}
    	}else
    		throw new Exception();
    		
        if(!array.isEmpty()){
        	
            Integer[] tab = array.toArray(new Integer[array.size()]);
            int max = Integer.MIN_VALUE;
            
            for(int j = 0; j < tab.length; j++)	
                System.out.print(tab[j] + " ");	
            System.out.println();	
            
            
            for(int j = 0; j < tab.length; j++){
            	if(tab[j] > max) 
                    max = tab[j];
            }
            System.out.println(max);
         
            
            for(int j = 0; j < tab.length; j++){	
                if(max == tab[j])
                    System.out.print(j + " ");
            }
            System.out.println();
        }		
    }catch(FileNotFoundException e){	
        System.out.println("***");
    } catch (Exception e){		
        System.out.println("***");			
    }
  }
}
