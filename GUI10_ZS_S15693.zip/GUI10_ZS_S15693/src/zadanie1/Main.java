/**
 *
 *  @author Zhura Serhii S15693
 *
 */

package zadanie1;


import javax.swing.JFrame;

public class Main {

  public static void main(String[] args) {
	  
	  WannaCry frame = new WannaCry();
	  
	  frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	  frame.setSize(500, 130);
	  frame.setVisible(true); 
  }
}
