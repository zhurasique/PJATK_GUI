/**
 *
 *  @author Zhura Serhii S15693
 *
 */

package zadanie1;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.JFrame;
import java.awt.BorderLayout;

public 
	class WannaCry extends JFrame implements ActionListener {

	private static final long serialVersionUID = 1L;
	
	public JButton button;
	public int output;
	
	public Color[] colors = new Color[] { 
			Color.BLACK, Color.CYAN, Color.GREEN, Color.RED, Color.YELLOW, Color.BLUE, Color.DARK_GRAY
			};

	public WannaCry() {
		initialize();
	}

	public void actionPerformed(ActionEvent e) {
		if (output < (colors.length - 1)) 
			output++;
		else 
			output = 0;
		
		button.setBackground(colors[output]);
	}
	
	public void initialize() {
		output = 0;

		button = new JButton("CLICK ON ME!");
		button.setFont(new Font("Truetype_Font", Font.TRUETYPE_FONT, 25));
		button.setToolTipText("WANNACRYYYYYYYYYYYYYYYY");
		button.addActionListener(this);
		
		setLayout(new BorderLayout());
		add(button, BorderLayout.CENTER);
	}
}
