package zadanie2;

/**
*
*  @author Zhura Serhii S15693
*
*/

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;


public 
	class SimpleEditor extends JFrame implements ActionListener {

	List<JMenuItem> fList = createMenuItems(
			"Open", "Save", "Save as"
			);
	
    char[] ftList = {
    		'O', 'S', 'A', 'X'
    		};
    
    List<JMenuItem> aList = createMenuItems(
    		"Dom", "Szkoła", "Firma"
    		);
    
    char[] atList = {
    		'D','S', 'F'
    		};
 
    List<JMenuItem> fgList = createColorMenuItems(
    		"Yellow","Orange","Black"
    		);
    
    List<JMenuItem> bgList = createColorMenuItems(
    		"Blue","Red","White"
    		);
    
    List<JMenuItem> fsList = createMenuItems(
    		"8 pts", "10 pts", "12 pts", "14 pts", "16 pts", "18 pts", "20 pts", "22 pts", "24 pts"
    		);
    

    JFileChooser file = null;	
    File last;	
    JMenuItem exit = new JMenuItem("Exit");
    JTextArea textArea = new JTextArea(10,20);
    
	public SimpleEditor() {
	    
	    JMenu s1 = new JMenu("File");
	    JMenu s2 = new JMenu("Adresy");
	    JMenu s3a = new JMenu("Foreground");
	    JMenu s3b = new JMenu("Background");
	    JMenu s3c = new JMenu("Font size");
	    JMenu s3d = new JMenu("Options");
	    JMenu s4 = new JMenu("Edit");
	    
	    addMenuOptions(s1, fList, ftList);
	    s1.addSeparator();
	    exit.setMnemonic('X');
	    exit.setAccelerator(KeyStroke.getKeyStroke((int) 'X', ActionEvent.CTRL_MASK));
	    exit.addActionListener(this);
	    s1.add(exit);
	    
	    addMenuOptions(s2, aList, atList);

	    addMenuOptions(s3a, fgList, null);
	    s3a.addSeparator();
	    addMenuOptions(s3b, bgList, null);
	    addMenuOptions(s3c, fsList, null);
	    
	    s3d.add(s3a);
	    s3d.add(s3b);
	    s3d.add(s3c);
	   
	    s4.add(s2);
	    
	    JMenuBar mb = new JMenuBar();
	    mb.add(s1);
	    mb.add(s4);
	    mb.add(s3d);
	    setJMenuBar(mb);
	    
	    add(new JScrollPane(textArea));
	   
	    setDefaultCloseOperation(DISPOSE_ON_CLOSE);
	    pack();
	    setLocationRelativeTo(null);
	    setVisible(true);
	    setTitle("Prosty edytor - " + "bez tytułu"); 
	    setSize(400, 280);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		
		if (e.getSource().equals(fList.get(0))) {
			JFileChooser open = new JFileChooser();
			open.setCurrentDirectory(last);
			int returnVal = open.showOpenDialog(this);
			if (returnVal == JFileChooser.APPROVE_OPTION) {
				try {
					BufferedReader br = new BufferedReader(new FileReader(open.getSelectedFile().getAbsolutePath()));
					textArea.read(br, null);
					br.close();
					textArea.requestFocus();
					setTitle("Prosty edytor - " + file.getSelectedFile().getAbsolutePath());
				} catch (Exception ex) {
					ex.printStackTrace();
				}
				file = open;
				last = file.getSelectedFile().getParentFile();
			}
		} else if (e.getSource().equals(fList.get(1))) {
			try {
				BufferedWriter bw = new BufferedWriter(new FileWriter(file.getSelectedFile().getAbsolutePath()));
				textArea.write(bw);
				bw.close();
				textArea.requestFocus();
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		} else if (e.getSource().equals(fList.get(2))) {
			JFileChooser saveAsFile = new JFileChooser();
			int returnVal = saveAsFile.showSaveDialog(this);
			if (returnVal == JFileChooser.APPROVE_OPTION) {
				file = saveAsFile;
				try {
					BufferedWriter bw = new BufferedWriter(new FileWriter(saveAsFile.getSelectedFile().getAbsolutePath()));
					textArea.write(bw);
					bw.close();
					textArea.requestFocus();
					setTitle("Prosty edytor - " + file.getSelectedFile().getAbsolutePath());
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		} else if (aList.contains(e.getSource())) {
			String address;
			if (e.getSource().equals(aList.get(0))) 
				address = " Lviv, ul.Rodzinna 98";
			  else if (e.getSource().equals(aList.get(0)))
				address = " Warszawa, ul.Koszykowa 64";
			  else 
				address = " Warszawa, ul.Konski Jar 10";
			textArea.insert(address, textArea.getCaretPosition());
		} else if (fsList.contains(e.getSource())) {
			int pts = Integer.parseInt( ( (JMenuItem)e.getSource() ).getText().split(" ")[0] );
			textArea.setFont(new Font("sansserif",Font.PLAIN,pts));
		} else if (fgList.contains(e.getSource())) {
			Color foregroundColor = Color.BLACK;
			String colorName = ((JMenuItem) e.getSource()).getText();
			for (int i=0; i < Reff.colorNames.length; i++) 
				if (colorName.equalsIgnoreCase(Reff.colorNames[i])) 
					foregroundColor = Reff.colors[i];
			textArea.setForeground(foregroundColor);
		} else if (bgList.contains(e.getSource())) {
			Color backgroundColor = Color.WHITE;
			String colorName = ((JMenuItem) e.getSource()).getText();
			for (int i=0; i < Reff.colorNames.length; i++) 
				if (colorName.equalsIgnoreCase(Reff.colorNames[i])) 
					backgroundColor = Reff.colors[i];
			textArea.setBackground(backgroundColor);
		} else if (e.getSource().equals(exit)) 
			System.exit(0);	
	}
	
	public void addMenuOptions(JMenu menu, List<JMenuItem> menuItems, char[] mnemonics) {
		for(int i = 0; i < menuItems.size(); i++) {
			JMenuItem mi = menuItems.get(i);
			if (mnemonics != null) { 
				mi.setMnemonic(mnemonics[i]);
				mi.setAccelerator(KeyStroke.getKeyStroke((int) mnemonics[i], ActionEvent.CTRL_MASK));
			}
			menu.add(mi);
		}
	}
	
	private List<JMenuItem> createMenuItems(String ... items) {
	    List<JMenuItem> list = new ArrayList<JMenuItem>();
	    for(String s : items) {
	      JMenuItem mi = new JMenuItem(s);
	      mi.addActionListener(this);
	      list.add(mi);
	    }
	    return list;
	}
	
	private List<JMenuItem> createColorMenuItems(String ... items) {
		List<JMenuItem> list = new ArrayList<JMenuItem>();
	    for(String s : items) {
	      JMenuItem mi = new JMenuItem(s);
	      mi.setIcon(new Reff(s));
	      mi.addActionListener(this);
	      list.add(mi);
	    }
	    return list;
	}
	
}
