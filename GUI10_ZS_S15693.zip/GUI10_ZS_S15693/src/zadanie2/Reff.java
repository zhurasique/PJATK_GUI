/**
 *
 *  @author Zhura Serhii S15693
 *
 */

package zadanie2;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;

import javax.swing.Icon;

public 
	class Reff implements Icon {

	private int diameter = 8; 
	Color iconColor = Color.WHITE;

	static Color[] colors = {
			Color.ORANGE, Color.RED, Color.YELLOW, Color.WHITE, Color.BLACK, Color.BLUE, Color.GREEN
			};
		
	static String[] colorNames = {
			"Orange", "Red", "Yellow", "White", "Black", "Blue", "Green"
			};
	
	public Reff(String colorName) {
		for (int i=0; i < colorNames.length; i++) 
			if (colorName.equalsIgnoreCase(colorNames[i])) 
				iconColor = colors[i];		
	}
	
	@Override
	public int getIconHeight() {
		return diameter;
	}

	@Override
	public int getIconWidth() {
		return diameter;
	}
	
	public Color getIconColor() {
		return iconColor;
	}

	@Override
	public void paintIcon(Component container, Graphics g, int p, int q) {
		g.setColor(iconColor);
		g.fillOval(p, q, diameter - 1, diameter - 1);		
	}
	
}

