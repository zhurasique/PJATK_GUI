/**
 *
 *  @author Zhura Serhii S15693
 *
 */

package Zadanie2;

import java.io.FileReader;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Finder {
	
	StringBuffer bufferMain;
	
	public Finder(String slowo)	throws IOException{
		
		FileReader reader = new FileReader(slowo);
		bufferMain = new StringBuffer();
		int countMain;
		while((countMain = reader.read()) != -1)
			bufferMain.append((char)countMain);
		
		reader.close();
	}

	public int getIfCount() throws IOException{
		
		Pattern pattern = Pattern.compile("(\".+\")|(\\/\\*.+\\*\\/)|(\\/\\/.+)");
		Matcher matcher = pattern.matcher(bufferMain); 
		bufferMain = new StringBuffer(matcher.replaceAll("")); 
		
		return getStringCount("if ?\\("); 
	}
		
	public int getStringCount(String slowo) throws IOException{
		
		Pattern pattern = Pattern.compile(slowo);
		Matcher matcher = pattern.matcher(bufferMain);
		int countString = 0;
		while(matcher.find())
			countString++;
		
		return countString;
	}
}   
