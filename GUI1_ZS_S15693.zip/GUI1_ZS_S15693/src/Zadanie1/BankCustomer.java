/**
 *
 *  @author Zhura Serhii S15693
 *
 */

package Zadanie1;

public class BankCustomer {

    public Person persona;
    public Account acc;

    public BankCustomer(Person persona) {
        this.persona = persona;
        acc = new Account();
    }

    public Account getAccount(){
        return acc;
    }

    public String toString(){
        return " Klient: " + persona + " stan konta " + acc;
    }
}
