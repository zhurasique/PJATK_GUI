/**
 *
 *  @author Zhura Serhii S15693
 *
 */

package Zadanie1;

public class Person {
	String imie;

    public Person(String imie) {
        this.imie = imie;
    }

    public String toString(){
        return imie;
    }
}
