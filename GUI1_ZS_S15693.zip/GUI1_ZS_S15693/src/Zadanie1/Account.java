/**
 *
 *  @author Zhura Serhii S15693
 *
 */

package Zadanie1;

public class Account {
	public double mMoney;
    public static double rate;

    public Account(){
        mMoney = 0;
    }

    public void deposit(double dMoney){
    	if(dMoney > 0){
        mMoney = mMoney + dMoney;
    	}else
    		System.out.println("Error <deposit>: Nie wolno doledowacz liczbe z minusem( - ).");
    }

    public void transfer(Account a, double tMoney){
        if(mMoney > 0 && mMoney - tMoney >= 0) {
            mMoney = mMoney - tMoney;
            a.deposit(tMoney);
        }else
            System.out.println("Error <transfer>: Nie dostatnio pieniendzy.");
    }

    public void withdraw(double wMoney){
        if(mMoney > 0 && mMoney - wMoney >= 0) {
            mMoney = mMoney - wMoney;
        }else
            System.out.println("Error <withdraw>: Nie dostatnio pieniendzy. ");
    }

    public static void setInterestRate(double iRate1){
        rate = iRate1;
    }

    public void addInterest() {
        mMoney = mMoney + mMoney * rate/100;
    }

    public String toString(){
        return mMoney + "";
    }
}
