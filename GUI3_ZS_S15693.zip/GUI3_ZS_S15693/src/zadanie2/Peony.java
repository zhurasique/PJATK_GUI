/**
 *
 *  @author Zhura Serhii S15693
 *
 */
package zadanie2;

public 
	class Peony extends FlowersList {
	
	
	public String color = "czerwony";
    public String name = "piwonia";
    public int quantity;

    
    public Peony(int quantity){
        this.quantity = quantity;
    }

    
    public String toName() {
        return name;
    }

    
    public String toColor() {
        return color;
    }

    
    public int toQuantity() {
        return quantity;
    }
}
