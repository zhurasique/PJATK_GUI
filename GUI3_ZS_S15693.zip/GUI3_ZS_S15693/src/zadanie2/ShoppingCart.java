/**
 *
 *  @author Zhura Serhii S15693
 *
 */
package zadanie2;

import java.util.ArrayList;

public class ShoppingCart {
	public ArrayList<FlowersList> flowers ;
	public Customer customer;
	public PriceList list;


    public ShoppingCart(Customer customer) {
        flowers = new ArrayList<>();
        list = PriceList.getInstance();
        this.customer = customer;
    }

    public void put(FlowersList flower){
        flowers.add(flower);
    }

    public void remove(FlowersList flower){
        flowers.remove(flower);
    }
    
    public void remove(){
        flowers = null;
    }
    
    public double getSum(){
        double count = 0;
        for (FlowersList flower : flowers)
        	count = count + flower.toQuantity() * list.getPrice(flower);
        return count;
    }

   

    public ArrayList<FlowersList> getShoppingCardItems(){
        return flowers;
    }

    public FlowersList maxPrice(){
        double max = 0;
        FlowersList maxFloverPrice = null;
        for (FlowersList flower : flowers){
            double sum = flower.toQuantity() * list.getPrice(flower);
            if (max < sum){
                maxFloverPrice = flower;
                max = sum;
            }
        }
        return maxFloverPrice;
    }

    
    public String toString() {
        if (flowers == null)
            return "Wózek własciciel " + customer.getImie() + " -- pusto";
        else if(flowers.isEmpty())
        	return "Wózek własciciel " + customer.getImie() + " -- pusto";
        
        String result = "Wózek własciciel " + customer.getImie() + "\n";
        for (FlowersList flower : flowers)
            result = result + flower.toName() + ", color: " +flower.toColor()+", ilość "
                    + flower.toQuantity() +", cena "+ list.getPrice(flower)+"\n";
        return result;
    }
}
