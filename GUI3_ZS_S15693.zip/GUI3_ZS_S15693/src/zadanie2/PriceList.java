package zadanie2;

import java.util.HashMap;

public 
	class PriceList {

	public static PriceList listOfPrices = null;
	public static HashMap<String, Double> listOfProducts;

    public static PriceList getInstance(){
        if (listOfPrices == null){
        	listOfProducts  = new HashMap<>();
            listOfPrices = new PriceList();
        }
        	
        return listOfPrices;
    }

    public void put(String string, double price){
        if (price < 0)
            return;
        listOfProducts.put(string, price);
    }

    public double getPrice(FlowersList flower){
        if (listOfProducts.containsKey(flower.toName())){
            return listOfProducts.get(flower.toName());
        }else{
            return -1;
        }
    }

    public boolean existItem(FlowersList flower){
        return listOfProducts.containsKey(flower.toName());
    }
}