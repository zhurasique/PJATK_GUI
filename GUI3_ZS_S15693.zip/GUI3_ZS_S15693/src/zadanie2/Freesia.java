/**
 *
 *  @author Zhura Serhii S15693
 *
 */
package zadanie2;

public 
	class Freesia extends FlowersList {
	
	
    public String color = "żółty";
    public String name = "frezja";
    public int quantity;

    
    public Freesia(int quantity){
        this.quantity = quantity;
    }

    
    public String toName() {
        return name;
    }

   
    public String toColor() {
        return color;
    }

    
    public int toQuantity() {
        return quantity;
    }
}
