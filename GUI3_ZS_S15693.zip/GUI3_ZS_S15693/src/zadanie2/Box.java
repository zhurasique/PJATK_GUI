/**
 *
 *  @author Zhura Serhii S15693
 *
 */
package zadanie2;

import java.util.ArrayList;

public class Box extends ShoppingCart{
	
    public Customer customer;
    public ArrayList<FlowersList> boxItems;
    public PriceList list;
    public ShoppingCart cart;

    public Box(Customer customer){
        super(customer);
        this.customer = customer;
        
        list = PriceList.getInstance();
        cart = customer.getShoppingCart();
    }

    public void pack(){
        boxItems = cart.getShoppingCardItems();
        cart.remove();
    }

    public double priceOf(String color){
        double count = 0;
        for (FlowersList flower : boxItems)
            if (flower.toColor().equals(color))
            	count = count + flower.toQuantity() * list.getPrice(flower);
        return count;
    }

    public String toString() {
        if (!boxItems.isEmpty()){
        	String result = "Pudełko własciciel " + customer.getImie() + "\n";
        for (FlowersList flower : boxItems)
            result = result + flower.toName() + ", color: " + flower.toColor() + ", ilość "
                    + flower.toQuantity() +", cena "+ list.getPrice(flower)+"\n";
        return result;
        }else
            return "Pudełko własciciel " + customer.getImie() + " -- pusto";
    }
}
