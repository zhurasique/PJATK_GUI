/**
 *
 *  @author Zhura Serhii S15693
 *
 */
package zadanie2;

public 
	class Lilac extends FlowersList {

	
	public String color = "biały";
	public String name = "bez";
    public int quantity;

    
    public Lilac(int quantity){
        this.quantity = quantity;
    }

    
    public String toName() {
        return name;
    }
    

    public String toColor() {
        return color;
    }
    

    public int toQuantity() {
        return quantity;
    }
}
