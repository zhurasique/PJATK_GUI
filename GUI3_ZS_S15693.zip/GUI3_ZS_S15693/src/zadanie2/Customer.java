/**
 *
 *  @author Zhura Serhii S15693
 *
 */
package zadanie2;

import java.util.ArrayList;

public class Customer {

    public String imie;
    public double cash;
    public ShoppingCart shoppingCart;
    public PriceList priceList;

    public Customer(String imie, double cash) {
    	shoppingCart = new ShoppingCart(this);
        priceList = PriceList.getInstance();
    	
    	this.imie = imie;

    	viewCash(cash);
    }

    public void viewCash(double cash){
    	if (cash < 0){
            this.cash = 0;
    	}else{
            this.cash = cash;
    	}
    }

    public void pay(){
        ArrayList<FlowersList> flowers = shoppingCart.getShoppingCardItems();
        for (FlowersList flower : flowers)
            if (!priceList.existItem(flower))
                shoppingCart.remove(flower);
        toPay();
    }
    
    public void toPay(){
    	double sum = shoppingCart.getSum();
       if (cash < sum){
            shoppingCart.remove(shoppingCart.maxPrice());
            sum = shoppingCart.getSum();
        }
        cash = cash - sum;
    }

    public void pack(Box box){
        box.pack();
    }
    

    public void get(FlowersList flower){
        shoppingCart.put(flower);
    }

    public String getImie() {
        return imie;
    }

    public double getCash() {
        return cash;
    }
    
    public ShoppingCart getShoppingCart(){
        return this.shoppingCart;
    }
}

