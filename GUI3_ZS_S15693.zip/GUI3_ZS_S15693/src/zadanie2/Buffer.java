package zadanie2;

public 
	class Buffer {

    public String imie;
    public double cash;
    public ShoppingCart shoppingCart;
    public PriceList priceList;
}
