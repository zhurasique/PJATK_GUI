/**
 *
 *  @author Zhura Serhii S15693
 *
 */
package zadanie2;

public 
	class Rose extends FlowersList{

    
    public String color = "czerwony";
    public String name = "róża";
    public int quantity;

    
    public Rose(int quantity){
        this.quantity = quantity;
    }

   
    public String toName() {
        return name;
    }

    
    public String toColor() {
        return color;
    }

   
    public int toQuantity() {
        return quantity;
    }
}