/**
 *
 *  @author Zhura Serhii S15693
 *
 */
package zadanie2;

public 
	abstract class FlowersList {

    abstract String toName();

    abstract String toColor();

    abstract int toQuantity();

}

