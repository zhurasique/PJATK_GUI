/**
 *
 *  @author Zhura Serhii S15693
 *
 */
package zadanie1;

public abstract class Pacjent {
	
	public String nazwisko;
	
	public Pacjent(String nazwisko){
		this.nazwisko = nazwisko;
	}
	
	public String nazwisko(){
		return nazwisko;
	}
	
	public abstract String choroba();
	public abstract String leczenie();
}
