/**
 *
 *  @author Zhura Serhii S15693
 *
 */
package zadanie1;

public class ChoryNaNoge extends Pacjent {

	public ChoryNaNoge(String nazwisko) {
		super(nazwisko);
	}
	
	public String choroba(){
		
		return "noga";
	}

	public String leczenie(){
		
		return "gips";
	}
}
