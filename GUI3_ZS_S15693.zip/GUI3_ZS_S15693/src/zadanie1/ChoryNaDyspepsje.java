/**
 *
 *  @author Zhura Serhii S15693
 *
 */
package zadanie1;

public class ChoryNaDyspepsje extends Pacjent {

	public ChoryNaDyspepsje(String nazwisko) {
		super(nazwisko);
	}
	
	public String choroba(){
		return "dyspepsja";
	}

	public String leczenie(){
		return "wegiel";
	}
}
