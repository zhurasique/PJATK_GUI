/**
 *
 *  @author Zhura Serhii S15693
 *
 */
package zadanie1;

public class ChoryNaGlowe extends Pacjent {

	public ChoryNaGlowe(String nazwisko) {
		super(nazwisko);
	}
	
	public String choroba(){
		
		return "glowa";
	}
	
	public String leczenie(){
		
		return "aspiryna";
	}

}
