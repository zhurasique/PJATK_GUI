/**
 *
 *  @author Zhura Serhii S15693
 *
 */

package zadanie2;

public enum MyState {
	CREATED, RUNNING, ABORTED, READY
}