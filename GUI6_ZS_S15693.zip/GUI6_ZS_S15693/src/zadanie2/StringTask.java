/**
 *
 *  @author Zhura Serhii S15693
 *
 */

package zadanie2;

public class StringTask implements Runnable {
	
	public volatile MyState state;
	public Thread stThread;
	public int intCount;
	public String string;
	public String finish;

	
	public StringTask(String string, int intCount) {
		state = MyState.CREATED;
		this.string = string;
		finish = "";
		
		this.intCount = intCount;
		stThread = new Thread(this);
	}
	
	public String getResult() {
		return finish;
	}
	
	
	public boolean isDone() {
		return state == MyState.READY || state == MyState.ABORTED;
	}

	
	public void start() {
		stThread.start();
		state = MyState.RUNNING;
	}

	
	public void abort() {
		state = MyState.ABORTED;
		stThread.interrupt();
	}
	

	@Override
	public void run() {
		for (int i = 0; i < intCount; i++) {
			if (Thread.interrupted() || state == MyState.ABORTED)
				return;
			finish += string;
		}
		state = MyState.READY;
	}

	
	public MyState getState() {
		return state;
	}
}
