/**
 *
 *  @author Zhura Serhii S15693
 *
 */

package zadanie1;

import java.util.*;

public
	class Letters {
	
	public final List<Thread> array;
	public boolean answer;

	public List<Thread> getThreads() {
		return Collections.unmodifiableList(array);
	}
	
	public Letters(String myString) {
		array = new LinkedList<>();

		for (int i = 0; i < myString.length(); i++) {
			char charArray = myString.charAt(i);
			
			Thread mainThread = new Thread(() -> {
				try {
					while (answer) {
						System.out.print(charArray);
						Thread.sleep(1000);
					}
				} catch (InterruptedException ex) {
				}
			}
			
			);
			
			mainThread.setName("Thread " + Character.toString(charArray));
			array.add(mainThread);
		}
	}

	public void letsStart() {
		answer = true;
		for (Thread thread : array)
			thread.start();
	}

	public void letsStop() throws InterruptedException {
		this.answer = false;
		boolean finish = false;
		
		do {
			Thread.sleep(500);
			finish = true;
			for (Thread th : array)
				if (th.isAlive()) {
					finish = false;
					break;
				}
		} while (!finish);
		
	}
}
