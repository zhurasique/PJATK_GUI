/**
 *
 *  @author Zhura Serhii S15693
 *
 */

package zadanie1;


public class Main {

  public static void main(String[] args) throws InterruptedException {
    Letters letters = new Letters("ABCD");
    for (Thread t : letters.getThreads()) System.out.println(t.getName());
    
    letters.letsStart(); 
    
    Thread.sleep(5000);

    letters.letsStop(); 
    
    System.out.println("\nProgram skończył działanie");
  }

}
