/**
 *
 *  @author Zhura Serhii S15693
 *
 */

package zadanie3;


public class Main {

  public static void main(String[] args) {
	  System.out.println("ZALICZENIE NA 5! =)");
  }
}
