/**
 *
 *  @author Zhura Serhii S15693
 *
 */

package zadanie1;


import java.text.DecimalFormat;

import javax.swing.*;

public 
	class Temperature extends AbstractListModel{

	@Override
	public Object getElementAt(int k) {
		
		k -= 70;
		
		double f = (k * 1.8) + 32;
		String string = new DecimalFormat("#0.0").format(f);
		
		return k + " stopni C = " + string + " stopni F";
	}

	@Override
	public int getSize() {
		return 131;
		// 131 bo od 70 + 60 + 1  - dla tego ze od -70 do 0 do 60
	}

}
