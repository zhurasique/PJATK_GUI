/**
 *
 *  @author Zhura Serhii S15693
 *
 */

package zadanie1;


import java.awt.Container;

import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JScrollPane;


public 
	class Main {
	public static void main(String[] args) {
		  
		  JList temperatureList = new JList(new Temperature());
		  
		  	JFrame frame = new JFrame();
			Container tmp = frame.getContentPane();
			tmp.add(new JScrollPane(temperatureList), "Center");
			frame.setLocationRelativeTo(null);
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			frame.setVisible(true);
			frame.pack();
	  }
}
