/**
 *
 *  @author Zhura Serhii S15693
 *
 */

package zadanie2;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.*;

public 
	class List {
	
	public JFrame frame = new JFrame("Clicker!");
	public JTextField field= new JTextField();
	public DefaultListModel<String> def = new DefaultListModel<String>();
	JList list = new JList(def);
	public boolean flag;
	
	public List(){
	
		field.addActionListener((ActionEvent e)->{
			def.addElement(e.getActionCommand());
		});
		
		
		list.addKeyListener(new KeyListener(){

			@Override
			public void keyPressed(KeyEvent arg0) {
				if (arg0.isAltDown())
					flag = true;
			}

			@Override
			public void keyReleased(KeyEvent arg0) {
				if (!arg0.isAltDown())
					flag = false;
			}

			@Override
			public void keyTyped(KeyEvent arg0) {}
			
		});
		
		list.addMouseListener(new MouseListener() {

			@Override
			public void mousePressed(MouseEvent e) {
				if (flag && !def.isEmpty())
					def.removeElementAt(list.getSelectedIndex());
			}
			
			@Override
			public void mouseReleased(MouseEvent e) {}
	
			@Override
			public void mouseClicked(MouseEvent e) {}

			@Override
			public void mouseEntered(MouseEvent e) {}

			@Override
			public void mouseExited(MouseEvent e) {}
			
		});
	
		Container ctr = frame.getContentPane();
		ctr.add(field, "North");
		ctr.add(new JScrollPane(list), "Center");
		
		frame.setPreferredSize(new Dimension(444, 444));
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.pack();
		frame.setVisible(true);
	}
}

