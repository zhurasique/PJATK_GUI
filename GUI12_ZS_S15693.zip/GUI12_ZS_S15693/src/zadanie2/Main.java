/**
 *
 *  @author Zhura Serhii S15693
 *
 */

package zadanie2;




import javax.swing.SwingUtilities;

public 
	class Main {
		public static void main(String[] args) {
			SwingUtilities.invokeLater(()->new List());
	}
}
