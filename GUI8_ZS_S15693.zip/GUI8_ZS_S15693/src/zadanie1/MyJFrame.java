/**
 *
 *  @author Zhura Serhii S15693
 *
 */

package zadanie1;

import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JPanel;

public 
	class MyJFrame extends JPanel {
	
	private static final long serialVersionUID = 0L; //nie potrzebne.

	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		
		g.drawLine(0, 0, getWidth(), getHeight()-1);
		g.drawLine(getWidth(), 0, 0, getHeight()-1);
		g.setColor(Color.BLUE);
	}
}
