/**
 *
 *  @author Zhura Serhii S15693
 *
 */

package zadanie1;

import javax.swing.JFrame;

public class Main {

  public static void main(String[] args) {
	  
	  JFrame frame = new JFrame("Przekątne!"); 
	  frame.setSize(500, 500); 
	  
	  MyJFrame myframe = new MyJFrame(); 
	  frame.add(myframe); 
	  frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	  frame.setVisible(true); 
	  
  }
}
