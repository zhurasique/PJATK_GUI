/**
 *
 *  @author Zhura Serhii S15693
 *
 */

package zadanie2;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.FilenameFilter;
import java.util.ArrayList;

public 
	class MySettings extends JPanel{
	
	private static final long serialVersionUID = 1L;
	
	public int textSize;
	public Image currImg;
	public MyPanel panel;
	public int timer;
	public Thread thread;
	public ArrayList<Image> img;
	public boolean ifLoaded;

    public MySettings(String[] args, MyPanel thisPanel) {
    	
    	textSize = Integer.parseInt(args[2]);
    	timer = Integer.parseInt(args[1] +"999");
        panel = thisPanel;
        loadImg(args[0]);
        setLayout(new FlowLayout());
        
        changeImg();
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        
        if (ifLoaded) {
            g.drawImage(currImg, 0, 0, getWidth(), getHeight(), this);
           
            if (!thread.isAlive()) 
                drawText(g, "Koniec prezentacji"); 
  
        }else
            drawText(g, "Brak obrazka");
    }
    
 // ========= CHANGING 
    public void changeImg(){
    	
        thread = new Thread(() -> {
        
            int size = img.size();
            for (int i = 0; i < size; i++) {
            	putImg();
                try {
                    Thread.sleep(timer);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            currImg = null;
            repaint();
            
        });
        
        thread.start();
    }

   // ========= TEXT
    public void drawText(Graphics g, String s){
        g.setFont(new Font("mFont", Font.BOLD, textSize));
        
        int x = (getWidth() - g.getFontMetrics().stringWidth(s)) / 2;
        int y = (g.getFontMetrics().getAscent() + (getHeight() - (g.getFontMetrics().getAscent() + g.getFontMetrics().getDescent())) / 2);
        g.drawString(s, x, y);
    }
    
   // ========= PUTTING
    public void putImg(){
    	currImg = img.get(0);
        img.remove(0);
        setPreferredSize(new Dimension(currImg.getWidth(this), currImg.getHeight(this)));
        panel.setSize(currImg.getWidth(this), currImg.getHeight(this));
        repaint();
    }

    // ======= MINI-STOS
    public ArrayList<Image> loadImg(String path){
    	img = new ArrayList<>();
        
        try {
            File directory = new File(path);
            final String[] EXTENSIONS = new String[]{".gif", ".png", ".jpg"};

            FilenameFilter filter = (File dir, String name) -> {
                for (String ext : EXTENSIONS)
                    if (name.endsWith(ext))
                        return true;         
                return false;
            };
            
            for (File file : directory.listFiles(filter)) 
            	img.add(ImageIO.read(file));
            
            ifLoaded = !img.isEmpty();
            
            if (!ifLoaded)
                setPreferredSize(new Dimension(600,600));
            
        }catch (Exception ex){
        	ifLoaded = !img.isEmpty();
            setPreferredSize(new Dimension(600,600));
            return img;
        }
        
        return img;
    }
}
