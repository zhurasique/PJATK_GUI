/**
 *
 *  @author Zhura Serhii S15693
 *
 */

package zadanie2;

import javax.swing.*;

public 
	class MyPanel extends JFrame {

	private static final long serialVersionUID = 1;
	
	public MyPanel(String[] args) {
        add(new MySettings(args, this));
        
        pack();
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }
	
}
