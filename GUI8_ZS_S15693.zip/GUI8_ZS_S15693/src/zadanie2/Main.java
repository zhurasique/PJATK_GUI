/**
 *
 *  @author Zhura Serhii S15693
 *
 */

package zadanie2;

public class Main{
	
	public static void main(String[] args) {
		new MyPanel(args);
  }
}
